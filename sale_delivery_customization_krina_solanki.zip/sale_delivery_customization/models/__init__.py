from . import res_partner
from . import sale_order
from . import stock_picking
from . import mrp_production
from . import product_category
from . import stock_rule
from . import purchase_order